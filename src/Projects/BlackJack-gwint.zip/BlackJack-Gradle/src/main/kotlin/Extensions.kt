
// Converts double to a money string
fun Double.toMoney(): String = "%.2f".format(this)
